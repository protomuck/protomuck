#define PROTOBASE "1.80b9"
  #define PROTOVER "Proto" PROTOBASE
#define NEONVER "Neon2.17"
#define VERSION "Muck2.2fb6.00b"

extern const char *infotext[];
