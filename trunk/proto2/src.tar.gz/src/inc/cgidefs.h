#define SPACE       ' '
#define TAB         '\t'
#define LF          '\n'
#define CR          '\r'
#define PLUS        '+'
#define PERCENT     '%'
#define EQUALS      '='
#define AMPERSAND   '&'
#define HYPHEN      '-'
#define UNDERSCORE  '_'
#define ATSIGN      '@'
#define SLASH       '/'

#define SEPARATOR   "&"
#define TRUE        1
#define FALSE       0

