typedef int dbref;

extern int notify(dbref player, const char *msg);
extern void log_status(char *format,...);

